## Average load display

A widget for [Übersicht](http://tracesof.net/uebersicht/) that displays a large number showing the average system load. The decimal point in the number is animated and color coded based on load (low, normal, high, higher, highest) and pulses faster as load increases. An arrow to the left shows whether the load is increasing or decreasing.

![](screenshot2.png)

### Notes

Adjust the refresh rate as desired.
